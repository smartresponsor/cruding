<?php

declare(strict_types=1);

namespace App\Cruding\EventSubscriber;

use App\Cruding\Service\Api\ApiProblemResponseFactory;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpKernel\Event\ExceptionEvent;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;
use Symfony\Component\HttpKernel\KernelEvents;

final readonly class ApiExceptionSubscriber implements EventSubscriberInterface
{
    public function __construct(private ApiProblemResponseFactory $problemResponseFactory)
    {
    }

    public static function getSubscribedEvents(): array
    {
        return [KernelEvents::EXCEPTION => 'onKernelException'];
    }

    public function onKernelException(ExceptionEvent $event): void
    {
        $request = $event->getRequest();
        if (!$this->isApiRequest($request)) {
            return;
        }

        $exception = $event->getThrowable();
        $extra = [
            'resourcePath' => $request->attributes->get('resourcePath'),
        ];

        $response = match (true) {
            $exception instanceof NotFoundHttpException => $this->problemResponseFactory->notFound($exception->getMessage() ?: 'Resource not found.', $extra),
            $exception instanceof AccessDeniedHttpException => $this->problemResponseFactory->forbidden($exception->getMessage() ?: 'Access denied.', $extra),
            $exception instanceof BadRequestHttpException => $this->problemResponseFactory->badRequest($exception->getMessage() ?: 'Bad request.', $extra),
            $exception instanceof HttpExceptionInterface => $this->problemResponseFactory->create(
                $exception->getStatusCode(),
                ResponseTitle::fromStatusCode($exception->getStatusCode()),
                $exception->getMessage() ?: 'HTTP error.',
                $extra,
            ),
            default => $this->problemResponseFactory->create(500, 'Internal Server Error', 'Unexpected API error.', $extra),
        };

        $event->setResponse($response);
    }

    private function isApiRequest(Request $request): bool
    {
        return str_starts_with($request->getPathInfo(), '/api/');
    }
}

final class ResponseTitle
{
    public static function fromStatusCode(int $statusCode): string
    {
        return match ($statusCode) {
            400 => 'Bad Request',
            401 => 'Unauthorized',
            403 => 'Forbidden',
            404 => 'Not Found',
            405 => 'Method Not Allowed',
            409 => 'Conflict',
            422 => 'Validation Failed',
            default => 'HTTP Error',
        };
    }
}
